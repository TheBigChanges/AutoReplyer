"""Tarif muddati: /setplan @user plus 1oy, avtomatik Bepulga qaytish."""
import asyncio
import os
import random
import sys
import time
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL")
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", TEST_DB_URL or "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402
import i18n  # noqa: E402
import logic  # noqa: E402

TZ = ZoneInfo("Asia/Tashkent")
ADMIN = 1


def run(c):
    return asyncio.run(c)


def ts(y, mo, d, h=12):
    return datetime(y, mo, d, h, tzinfo=TZ).timestamp()


class DurationParsingTests(unittest.TestCase):
    def test_valid_forms(self):
        f = logic.parse_plan_duration
        self.assertEqual(f("1oy"), (1, "month"))
        self.assertEqual(f("3 oy"), (3, "month"))
        self.assertEqual(f("30kun"), (30, "day"))
        self.assertEqual(f("2hafta"), (2, "week"))
        self.assertEqual(f("1yil"), (1, "year"))
        self.assertEqual(f("2 Months"), (2, "month"))
        self.assertEqual(f("7days"), (7, "day"))

    def test_invalid_forms(self):
        f = logic.parse_plan_duration
        for bad in ("", "oy", "0oy", "-1oy", "1", "1soat", "abc", "1.5oy", "99999kun", "50yil", None):
            self.assertIsNone(f(bad), bad)

    def test_calendar_arithmetic(self):
        add = lambda start, n, k: datetime.fromtimestamp(logic.add_plan_duration(start, n, k, TZ), TZ)  # noqa: E731
        self.assertEqual(add(ts(2026, 10, 12), 1, "month").date().isoformat(), "2026-11-12")
        self.assertEqual(add(ts(2026, 1, 31), 1, "month").date().isoformat(), "2026-02-28")
        self.assertEqual(add(ts(2028, 1, 31), 1, "month").date().isoformat(), "2028-02-29")
        self.assertEqual(add(ts(2026, 12, 15), 1, "month").date().isoformat(), "2027-01-15")
        self.assertEqual(add(ts(2026, 12, 15), 14, "month").date().isoformat(), "2028-02-15")
        self.assertEqual(add(ts(2026, 10, 12), 1, "year").date().isoformat(), "2027-10-12")
        self.assertEqual(add(ts(2028, 2, 29), 1, "year").date().isoformat(), "2029-02-28")
        self.assertEqual(add(ts(2026, 10, 12), 30, "day").date().isoformat(), "2026-11-11")
        self.assertEqual(add(ts(2026, 10, 12), 2, "week").date().isoformat(), "2026-10-26")
        self.assertEqual(add(ts(2026, 10, 12), 1, "month").hour, 12)


class SetPlanDurationTests(unittest.TestCase):
    def _run(self, args, lang="uz"):
        u = MagicMock()
        u.effective_user.id = ADMIN
        u.message.reply_text = AsyncMock()
        c = MagicMock()
        c.args = args
        with patch.object(bot, "ADMIN_ID", ADMIN), patch.object(bot, "resolve_target_user", AsyncMock(return_value=(77, None))), \
             patch.object(db, "set_user_plan") as setp, patch.object(db, "get_user", return_value={}), \
             patch.object(bot, "get_lang", return_value=lang), patch.object(bot, "_try_send", AsyncMock(return_value=True)) as send:
            run(bot.cmd_setplan(u, c))
        return setp, send, u

    def test_one_month_sets_expiry_and_tells_user_the_date(self):
        before = time.time()
        setp, send, u = self._run(["@ali", "plus", "1oy"])
        user_id, plan, expires = setp.call_args.args
        self.assertEqual((user_id, plan), (77, "plus"))
        self.assertGreater(expires, before + 27 * 86400)
        self.assertLess(expires, before + 32 * 86400)
        date = bot.format_plan_date(expires)
        self.assertEqual(send.call_args.args[2], i18n.T["plan_activated_until"]["uz"].format(name="Plus", date=date))
        self.assertIn(date, u.message.reply_text.call_args.args[0])

    def test_user_message_in_english(self):
        _, send, _ = self._run(["@ali", "pro", "30kun"], lang="en")
        self.assertIn("Valid until", send.call_args.args[2])

    def test_without_duration_is_unlimited(self):
        setp, send, u = self._run(["@ali", "ultra"])
        self.assertEqual(setp.call_args.args, (77, "ultra", None))
        self.assertIn("muddatsiz", u.message.reply_text.call_args.args[0])
        self.assertEqual(send.call_args.args[2], i18n.T["plan_activated"]["uz"].format(name="Ultra"))

    def test_bad_duration_rejected_without_changes(self):
        setp, send, u = self._run(["@ali", "plus", "abc"])
        setp.assert_not_called()
        send.assert_not_called()
        self.assertIn("Muddat noto'g'ri", u.message.reply_text.call_args.args[0])

    def test_free_with_duration_rejected_and_free_without_ok(self):
        setp, _, _ = self._run(["@ali", "free", "1oy"])
        setp.assert_not_called()
        setp, _, _ = self._run(["@ali", "free"])
        setp.assert_called_once_with(77, "free", None)

    def test_too_many_args(self):
        setp, _, _ = self._run(["@ali", "plus", "1oy", "x"])
        setp.assert_not_called()

    def test_help_mentions_duration(self):
        self.assertIn("1oy", bot.ADMIN_HELP_TEXT)


class ExpiryJobTests(unittest.TestCase):
    def test_expired_users_notified_in_their_language(self):
        ctx = MagicMock()
        with patch.object(db, "expire_plans", return_value=[(5, "pro"), (6, "plus")]), \
             patch.object(bot, "get_lang", side_effect=lambda uid: {5: "ru", 6: "en"}[uid]), \
             patch.object(bot, "_try_send", AsyncMock(return_value=True)) as send:
            run(bot.plan_expiry_job(ctx))
        texts = {c.args[1]: c.args[2] for c in send.call_args_list}
        self.assertEqual(texts[5], i18n.T["plan_expired"]["ru"].format(name="Pro"))
        self.assertEqual(texts[6], i18n.T["plan_expired"]["en"].format(name="Plus"))

    def test_nothing_expired_sends_nothing(self):
        with patch.object(db, "expire_plans", return_value=[]), patch.object(bot, "_try_send", AsyncMock()) as send:
            run(bot.plan_expiry_job(MagicMock()))
        send.assert_not_called()

    def test_db_error_does_not_crash(self):
        with patch.object(db, "expire_plans", side_effect=RuntimeError("x")), patch.object(bot, "_try_send", AsyncMock()) as send:
            run(bot.plan_expiry_job(MagicMock()))
        send.assert_not_called()

    def test_job_registered(self):
        import inspect
        self.assertIn("plan_expiry_job", inspect.getsource(bot.build_app))

    def test_current_plan_screen_shows_expiry_date(self):
        exp = ts(2026, 11, 12)
        with patch.object(bot, "get_lang", return_value="uz"), patch.object(db, "get_user_plan", return_value="plus"), \
             patch.object(db, "get_user_plan_info", return_value=("plus", exp)):
            text, _ = bot.build_plan_view(9, "plus")
        self.assertIn("12.11.2026", text)


@unittest.skipUnless(TEST_DB_URL, "TEST_DATABASE_URL yo'q")
class ExpiryDbTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()
        db.init_db()

    def setUp(self):
        self.uid = random.randint(10**14, 10**15)
        self.addCleanup(self._cleanup)

    def _cleanup(self):
        with db.get_conn() as c, c.cursor() as cur:
            cur.execute("DELETE FROM users WHERE user_id = %s", (self.uid,))

    def test_active_paid_plan_with_future_expiry(self):
        exp = time.time() + 3600
        db.set_user_plan(self.uid, "plus", exp)
        plan, got = db.get_user_plan_info(self.uid)
        self.assertEqual(plan, "plus")
        self.assertAlmostEqual(got, exp, places=3)

    def test_expired_plan_reads_as_free_immediately(self):
        db.set_user_plan(self.uid, "pro", time.time() - 1)
        self.assertEqual(db.get_user_plan(self.uid), "free")
        self.assertEqual(db.get_user_plan_info(self.uid), ("free", None))

    def test_unlimited_plan_never_expires(self):
        db.set_user_plan(self.uid, "ultra")
        self.assertNotIn(self.uid, [u for u, _ in db.expire_plans(time.time() + 10**9)])
        self.assertEqual(db.get_user_plan(self.uid), "ultra")

    def test_expire_plans_downgrades_only_expired_and_reports_once(self):
        other = self.uid + 1
        self.addCleanup(lambda: self._del(other))
        db.set_user_plan(self.uid, "pro", time.time() - 5)
        db.set_user_plan(other, "plus", time.time() + 3600)
        first = db.expire_plans()
        self.assertIn((self.uid, "pro"), first)
        self.assertNotIn(other, [u for u, _ in first])
        self.assertNotIn((self.uid, "pro"), db.expire_plans())  # ikkinchi marta xabar berilmaydi
        self.assertEqual(db.get_user_plan(other), "plus")
        self.assertEqual(db.get_user_plan(self.uid), "free")

    def _del(self, uid):
        with db.get_conn() as c, c.cursor() as cur:
            cur.execute("DELETE FROM users WHERE user_id = %s", (uid,))

    def test_renewal_replaces_expiry_and_free_clears_it(self):
        db.set_user_plan(self.uid, "plus", time.time() + 100)
        later = time.time() + 5000
        db.set_user_plan(self.uid, "plus", later)
        self.assertAlmostEqual(db.get_user_plan_info(self.uid)[1], later, places=3)
        db.set_user_plan(self.uid, "free", later)
        self.assertEqual(db.get_user_plan_info(self.uid), ("free", None))
