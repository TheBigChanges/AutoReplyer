"""Botlarni bazaga yozmaslik va /bots orqali tozalash."""

import asyncio
import os
import random
import sys
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL")
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", TEST_DB_URL or "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402

ADMIN = 777


def run(coro):
    return asyncio.run(coro)


class BotFilterTests(unittest.TestCase):
    def test_bot_is_not_tracked(self):
        with patch.object(db, "record_user") as r:
            bot.track_user(MagicMock(id=1, is_bot=True))
        r.assert_not_called()

    def test_human_is_tracked(self):
        with patch.object(db, "record_user") as r:
            bot.track_user(MagicMock(id=1, is_bot=False, username="a", full_name="A"))
        r.assert_called_once()


class BotsCommandTests(unittest.TestCase):
    def setUp(self):
        p = patch.object(bot, "ADMIN_ID", ADMIN)
        p.start()
        self.addCleanup(p.stop)

    def test_non_admin_ignored(self):
        u = MagicMock()
        u.effective_user.id = 5
        u.message.reply_text = AsyncMock()
        run(bot.cmd_bots(u, MagicMock()))
        u.message.reply_text.assert_not_called()

    def test_lists_candidates_with_confirm_buttons(self):
        u = MagicMock()
        u.effective_user.id = ADMIN
        u.message.reply_text = AsyncMock()
        rows = [{"user_id": 9, "username": "allsaverbot", "full_name": "Downloader"}]
        with patch.object(db, "list_bot_like_users", return_value=rows):
            run(bot.cmd_bots(u, MagicMock()))
        text = u.message.reply_text.call_args.args[0]
        self.assertIn("allsaverbot", text)
        buttons = u.message.reply_text.call_args.kwargs["reply_markup"].inline_keyboard[0]
        self.assertEqual([b.callback_data for b in buttons], ["rmbots:yes", "rmbots:no"])

    def test_nothing_deleted_without_confirmation(self):
        q = MagicMock()
        q.from_user.id = ADMIN
        q.answer = AsyncMock()
        q.edit_message_text = AsyncMock()
        with patch.object(db, "delete_bot_like_users") as d:
            run(bot.handle_rmbots(q, MagicMock(), "rmbots:no"))
        d.assert_not_called()
        q.answer.assert_awaited_once()

    def test_confirm_deletes_once_and_non_admin_cannot(self):
        q = MagicMock()
        q.from_user.id = 5
        q.answer = AsyncMock()
        with patch.object(db, "delete_bot_like_users") as d:
            run(bot.handle_rmbots(q, MagicMock(), "rmbots:yes"))
        d.assert_not_called()

        q.from_user.id = ADMIN
        q.answer = AsyncMock()
        q.edit_message_text = AsyncMock()
        with patch.object(db, "delete_bot_like_users", return_value=2) as d:
            run(bot.handle_rmbots(q, MagicMock(), "rmbots:yes"))
        d.assert_called_once()
        q.answer.assert_awaited_once()

    def test_admin_help_lists_bots(self):
        self.assertIn("/bots", bot.ADMIN_HELP_TEXT)


@unittest.skipUnless(TEST_DB_URL, "TEST_DATABASE_URL yo'q")
class BotsDbTests(unittest.TestCase):
    def setUp(self):
        import psycopg2

        self.psycopg2 = psycopg2
        base = random.randint(10**14, 10**15)
        self.bot_id, self.human, self.owner_bot = base, base + 1, base + 2
        self.tag = f"zz{base}"
        p = patch.object(db, "get_conn", self._conn)
        p.start()
        self.addCleanup(p.stop)
        db.init_db()

    def _conn(self):
        c = self.psycopg2.connect(TEST_DB_URL)
        c.autocommit = True

        class Ctx:
            def __enter__(s):
                return c

            def __exit__(s, *a):
                c.close()
                return False

        return Ctx()

    def tearDown(self):
        c = self.psycopg2.connect(TEST_DB_URL)
        c.autocommit = True
        with c.cursor() as cur:
            cur.execute("DELETE FROM users WHERE user_id = ANY(%s)", ([self.bot_id, self.human, self.owner_bot],))
        c.close()

    def test_only_bot_like_unconnected_rows_deleted(self):
        db.record_user(self.bot_id, username=f"{self.tag}Bot", full_name="B")
        db.record_user(self.human, username=self.tag, full_name="H")
        found = {r["user_id"] for r in db.list_bot_like_users(10**6)}
        self.assertIn(self.bot_id, found)
        self.assertNotIn(self.human, found)
        db.delete_bot_like_users()
        self.assertIsNone(db.get_user(self.bot_id))
        self.assertIsNotNone(db.get_user(self.human))


if __name__ == "__main__":
    unittest.main()
