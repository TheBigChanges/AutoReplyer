"""Bepul tarifga reklama: avtojavob ostiga va ism soati uchun BIO'ga; pullik tariflarda yo'q."""
import asyncio
import os
import random
import sys
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL")
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", TEST_DB_URL or "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402
import i18n  # noqa: E402
from telegram.error import TelegramError  # noqa: E402

OWNER, ADMIN = 9, 1
run = asyncio.run
AD_UZ = "\U0001F680 Ushbu xabar @autoreplyer_dbot orqali yuborildi!"
BIO_UZ = "\U0001F680 Ushbu soat @autoreplyer_dbot orqali o'rnatildi!"


class Base(unittest.TestCase):
    def setUp(self):
        p = patch.object(bot, "shows_ads", _real_shows_ads)
        p.start()
        self.addCleanup(p.stop)
        p = patch.object(bot, "ADMIN_ID", ADMIN)
        p.start()
        self.addCleanup(p.stop)
        bot._lang_cache.clear()

    def plan(self, plan, lang="uz"):
        for target, val in (("get_user_plan", plan), ("get_user_lang", lang)):
            p = patch.object(db, target, return_value=val)
            p.start()
            self.addCleanup(p.stop)


def _real_shows_ads(user_id, plan=None):
    if user_id == ADMIN:
        return False
    return (plan if plan is not None else bot.plan_of(user_id)) not in bot.AD_FREE_PLANS


class ReplyAdTests(Base):
    def _send(self, text, owner=OWNER):
        b = MagicMock()
        b.send_message = AsyncMock(return_value=MagicMock(message_id=1))
        bm = MagicMock(business_connection_id="bc")
        with patch.object(db, "try_claim_reply", return_value=1.0):
            run(bot.send_auto_reply(b, bm, owner, 5, text, 1, "x"))
        return b.send_message.call_args.kwargs["text"]

    def test_free_gets_ad_after_two_line_breaks(self):
        self.plan("free")
        self.assertEqual(self._send("Oflaynman"), "Oflaynman\n\n" + AD_UZ)

    def test_paid_plans_and_admin_have_no_ad(self):
        for plan in ("plus", "pro", "ultra"):
            self.plan(plan)
            self.assertEqual(self._send("Oflaynman"), "Oflaynman")
            patch.stopall()
            self.setUp()
        self.plan("free")
        self.assertEqual(self._send("Oflaynman", owner=ADMIN), "Oflaynman")

    def test_ad_is_in_owner_language(self):
        self.plan("free", "en")
        self.assertTrue(self._send("Hi").endswith("This message was sent via @autoreplyer_dbot!"))
        patch.stopall(); self.setUp(); bot._lang_cache.clear()
        self.plan("free", "ru")
        self.assertTrue(self._send("Привет").endswith("@autoreplyer_dbot!"))

    def test_long_text_is_trimmed_to_keep_telegram_limit_and_ad(self):
        self.plan("free")
        out = self._send("x" * 5000)
        self.assertLessEqual(len(out), 4096)
        self.assertTrue(out.endswith(AD_UZ))

    def test_exact_texts(self):
        self.assertEqual(i18n.t("uz", "ad_reply"), AD_UZ)
        self.assertEqual(i18n.t("uz", "ad_bio"), BIO_UZ)


class PlanScreenTests(Base):
    def test_free_says_with_ads_paid_say_no_ads(self):
        self.assertIn("• Reklama bilan", bot.plan_features_text("uz", "free"))
        self.assertNotIn("Reklama yo'q", bot.plan_features_text("uz", "free"))
        for plan in ("plus", "pro", "ultra"):
            text = bot.plan_features_text("uz", plan)
            self.assertIn("• Reklama yo'q", text)
            self.assertNotIn("Reklama bilan", text)
        self.assertIn("With ads", bot.plan_features_text("en", "free"))
        self.assertIn("Без рекламы", bot.plan_features_text("ru", "pro"))


class BioAdTests(Base):
    def _row(self, **kw):
        row = {"owner_user_id": OWNER, "business_connection_id": "bc", "name_clock_enabled": True, "clock_bio_ad": False,
               "bio_countdown_target": None, "birthday_month": None, "birthday_day": None, "lang": "uz", "plan": "free"}
        row.update(kw)
        return row

    def _go(self, row, bio_ok=True):
        b = MagicMock()
        b.set_business_account_bio = AsyncMock(side_effect=None if bio_ok else TelegramError("x"))
        with patch.object(db, "get_bio_ad_candidates", return_value=[row]), \
             patch.object(db, "update_settings") as upd, patch.object(bot.asyncio, "sleep", new=AsyncMock()):
            run(bot.reconcile_clock_bio_ads(b))
        return b.set_business_account_bio, upd

    def test_free_with_clock_gets_ad_in_bio_once(self):
        setbio, upd = self._go(self._row())
        setbio.assert_awaited_once_with(business_connection_id="bc", bio=BIO_UZ)
        upd.assert_called_once_with(OWNER, clock_bio_ad=True)
        setbio, upd = self._go(self._row(clock_bio_ad=True))  # allaqachon yozilgan
        setbio.assert_not_awaited()

    def test_paid_plan_gets_no_ad(self):
        setbio, _ = self._go(self._row(plan="pro"))
        setbio.assert_not_awaited()

    def test_ad_removed_when_clock_off_or_plan_upgraded(self):
        for kw in ({"name_clock_enabled": False}, {"plan": "plus"}):
            setbio, upd = self._go(self._row(clock_bio_ad=True, **kw))
            setbio.assert_awaited_once_with(business_connection_id="bc", bio="")
            upd.assert_called_once_with(OWNER, clock_bio_ad=False)

    def test_upgrade_to_pro_restores_bio_countdown(self):
        row = self._row(clock_bio_ad=True, plan="pro", bio_countdown_target="new_year")
        setbio, _ = self._go(row)
        self.assertNotEqual(setbio.call_args.kwargs["bio"], "")
        self.assertNotIn("autoreplyer", setbio.call_args.kwargs["bio"])

    def test_failure_keeps_state_for_retry(self):
        _, upd = self._go(self._row(), bio_ok=False)
        upd.assert_not_called()

    def test_not_subscribed_does_not_get_new_ad(self):
        with patch.object(bot, "sub_ok_sync", return_value=False):
            setbio, _ = self._go(self._row())
        setbio.assert_not_awaited()


@unittest.skipUnless(TEST_DB_URL, "TEST_DATABASE_URL yo'q")
class AdDbTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()

    def setUp(self):
        self.uid = random.randint(10**14, 10**15)
        self.addCleanup(self._cleanup)
        db.record_user(self.uid, username="u", full_name="U")
        db.upsert_connection(owner_user_id=self.uid, business_connection_id=f"bc{self.uid}", can_reply=True,
                             is_enabled=True, can_edit_bio=True, can_edit_name=True)

    def _cleanup(self):
        with db.get_conn() as c, c.cursor() as cur:
            for table, col in (("connections", "owner_user_id"), ("settings", "owner_user_id"), ("users", "user_id")):
                cur.execute(f"DELETE FROM {table} WHERE {col} = %s", (self.uid,))

    def _row(self):
        return next((r for r in db.get_bio_ad_candidates() if r["owner_user_id"] == self.uid), None)

    def test_candidates_follow_clock_and_ad_flag(self):
        db.update_settings(self.uid, name_clock_enabled=False)
        self.assertIsNone(self._row())
        db.update_settings(self.uid, name_clock_enabled=True)
        self.assertEqual(self._row()["plan"], "free")
        self.assertFalse(self._row()["clock_bio_ad"])
        db.update_settings(self.uid, name_clock_enabled=False, clock_bio_ad=True)
        self.assertTrue(self._row()["clock_bio_ad"])  # olib tashlash uchun hali ro'yxatda

    def test_no_bio_permission_means_not_listed(self):
        db.upsert_connection(owner_user_id=self.uid, business_connection_id=f"bc{self.uid}", can_reply=True,
                             is_enabled=True, can_edit_bio=False, can_edit_name=True)
        db.update_settings(self.uid, name_clock_enabled=True)
        self.assertIsNone(self._row())


if __name__ == "__main__":
    unittest.main()
