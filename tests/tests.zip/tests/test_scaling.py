"""Ko'p foydalanuvchi: tezlik cheklovi, adaptiv oldinlik, bazaga qayta urinish."""
import asyncio
import os
import random
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import psycopg2

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL")
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", TEST_DB_URL or "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402


def run(c):
    return asyncio.run(c)


def target(i):
    return {"owner_user_id": i, "business_connection_id": f"bc{i}", "name_clock_tz": "Asia/Tashkent",
            "name_clock_first": "Ali", "name_clock_last": "", "name_clock_applied": None,
            "name_clock_style": "default", "plan": "ultra"}


class PacerTests(unittest.TestCase):
    def test_calls_are_spread_at_the_given_rate(self):
        async def go():
            pacer = bot._Pacer()
            t0 = time.monotonic()
            await asyncio.gather(*(pacer.wait(100.0) for _ in range(21)))
            return time.monotonic() - t0
        elapsed = run(go())
        self.assertGreaterEqual(elapsed, 0.19)   # 20 oraliq x 10 ms
        self.assertLess(elapsed, 0.6)

    def test_idle_pacer_does_not_delay_first_call(self):
        async def go():
            pacer = bot._Pacer()
            t0 = time.monotonic()
            await pacer.wait(5.0)
            return time.monotonic() - t0
        self.assertLess(run(go()), 0.05)

    def test_tick_is_rate_limited_but_updates_everyone(self):
        tg = MagicMock()
        stamps = []

        async def setname(**kw):
            stamps.append(time.monotonic())
        tg.set_business_account_name = setname
        bot._name_clock_inflight.clear()
        bot._name_clock_backoff_until = 0.0
        with patch.object(bot, "NAME_CLOCK_RATE_PER_SEC", 200.0), patch.object(bot, "_clock_pacer", bot._Pacer()), \
             patch.object(db, "get_name_clock_targets", return_value=[target(i) for i in range(41)]), \
             patch.object(db, "mark_name_clock_applied_bulk") as bulk:
            run(bot.name_clock_tick(tg, 1760000000.0))
        self.assertEqual(len(stamps), 41)
        self.assertGreaterEqual(max(stamps) - min(stamps), 0.18)
        self.assertEqual(len(bulk.call_args.args[0]), 41)

    def test_sync_is_rate_limited_too(self):
        tg = MagicMock()
        tg.get_chat = AsyncMock(return_value=MagicMock(first_name="Ali", last_name=None))
        with patch.object(bot, "NAME_CLOCK_RATE_PER_SEC", 200.0), patch.object(bot, "_sync_pacer", bot._Pacer()), \
             patch.object(db, "get_name_clock_targets", return_value=[target(i) for i in range(41)]), \
             patch.object(bot, "adopt_new_base_name"):
            t0 = time.monotonic()
            run(bot.name_clock_sync(tg))
        self.assertGreaterEqual(time.monotonic() - t0, 0.18)
        self.assertEqual(tg.get_chat.await_count, 41)


class LeadTests(unittest.TestCase):
    def setUp(self):
        p = patch.object(bot, "NAME_CLOCK_RATE_PER_SEC", 20.0)
        p.start()
        self.addCleanup(p.stop)

    def test_lead_grows_with_users_and_is_capped(self):
        self.assertAlmostEqual(bot.clock_lead_seconds(0), bot.NAME_CLOCK_LEAD_SECONDS)
        self.assertAlmostEqual(bot.clock_lead_seconds(100), bot.NAME_CLOCK_LEAD_SECONDS + 5.0)
        self.assertEqual(bot.clock_lead_seconds(10_000), bot.NAME_CLOCK_MAX_LEAD_SECONDS)

    def test_sync_finishes_before_tick_starts(self):
        for n in (0, 10, 100, 300):
            sync_lead = bot.clock_sync_lead_seconds(n)
            tick_lead = bot.clock_lead_seconds(n)
            sync_duration = n / 20.0
            self.assertGreater(sync_lead - sync_duration, tick_lead, n)   # tekshiruv tugagach yangilash boshlanadi
            self.assertLess(sync_lead, 60.0)

    def test_boundary_uses_given_lead(self):
        now = 1760000010.0   # daqiqaning 10-soniyasi atrofida
        boundary = (now // 60 + 1) * 60
        fire, b = bot.next_clock_boundary(now, 5.8)
        self.assertEqual(b, boundary)
        self.assertAlmostEqual(fire, boundary - 5.8)
        fire_default, _ = bot.next_clock_boundary(now)
        self.assertAlmostEqual(fire_default, boundary - bot.NAME_CLOCK_LEAD_SECONDS)

    def test_boundary_rolls_over_when_lead_window_already_passed(self):
        boundary = (1760000000.0 // 60 + 1) * 60
        now = boundary - 3.0
        fire, b = bot.next_clock_boundary(now, 5.8)
        self.assertEqual(b, boundary + 60)
        self.assertGreater(fire, now)

    def test_tick_records_user_count_for_next_lead(self):
        tg = MagicMock()
        tg.set_business_account_name = AsyncMock()
        bot._name_clock_inflight.clear()
        bot._name_clock_backoff_until = 0.0
        with patch.object(db, "get_name_clock_targets", return_value=[target(i) for i in range(100)]), \
             patch.object(db, "mark_name_clock_applied_bulk"):
            run(bot.name_clock_tick(tg, 1760000000.0))
        self.assertEqual(bot._name_clock_target_count, 100)
        self.assertAlmostEqual(bot.clock_lead_seconds(), bot.NAME_CLOCK_LEAD_SECONDS + 5.0)
        bot._name_clock_target_count = 0


class RetryTests(unittest.TestCase):
    def test_retries_once_on_connection_error(self):
        calls = []

        def flaky():
            calls.append(1)
            if len(calls) == 1:
                raise psycopg2.OperationalError("server closed the connection")
            return "ok"
        self.assertEqual(db.retry_on_disconnect(flaky)(), "ok")
        self.assertEqual(len(calls), 2)

    def test_second_failure_propagates(self):
        def dead():
            raise psycopg2.InterfaceError("connection already closed")
        with self.assertRaises(psycopg2.InterfaceError):
            db.retry_on_disconnect(dead)()

    def test_non_connection_errors_are_not_retried(self):
        calls = []

        def bad():
            calls.append(1)
            raise psycopg2.IntegrityError("dup")
        with self.assertRaises(psycopg2.IntegrityError):
            db.retry_on_disconnect(bad)()
        self.assertEqual(len(calls), 1)

    def test_hot_functions_are_wrapped(self):
        for name in ("get_name_clock_targets", "mark_name_clock_applied_bulk", "get_settings",
                     "get_connection_by_business_id", "get_user_plan_info", "get_user_lang"):
            self.assertTrue(hasattr(getattr(db, name), "__wrapped__"), name)

    def test_non_idempotent_writes_are_not_wrapped(self):
        for name in ("try_claim_reply", "record_referral", "add_feedback"):
            self.assertFalse(hasattr(getattr(db, name), "__wrapped__"), name)


@unittest.skipUnless(TEST_DB_URL, "TEST_DATABASE_URL yo'q")
class RetryRealDbTests(unittest.TestCase):
    def test_recovers_after_killed_connection(self):
        db.init_db()
        uid = random.randint(10**14, 10**15)
        self.addCleanup(lambda: _cleanup(uid))
        db.set_user_lang(uid, "ru")
        # Pool'dagi barcha ulanishlarni serverdan uzib tashlaymiz (Supabase uzib qo'ygandek)
        with db.get_conn() as c, c.cursor() as cur:
            cur.execute("SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
                        "WHERE datname = current_database() AND pid <> pg_backend_pid() AND usename IS NOT NULL")
        self.assertEqual(db.get_user_lang(uid), "ru")  # birinchi urinish yiqiladi, ikkinchisi yangi ulanish bilan o'tadi


def _cleanup(uid):
    with db.get_conn() as c, c.cursor() as cur:
        cur.execute("DELETE FROM users WHERE user_id = %s", (uid,))
