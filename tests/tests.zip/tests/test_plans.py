"""Tariflar: menyu, to'lov ekrani (karta), tilga moslik, /setplan va baza."""
import asyncio
import os
import random
import re
import sys
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
TEST_DB_URL = os.environ.get("TEST_DATABASE_URL")
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", TEST_DB_URL or "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402
import i18n  # noqa: E402

USER, ADMIN = 9, 1


def run(c):
    return asyncio.run(c)


def buttons(markup):
    return [b for row in markup.inline_keyboard for b in row]


class Base(unittest.TestCase):
    def setUp(self):
        bot._lang_cache.clear()
        for p in (patch.object(db, "record_user"), patch.object(db, "get_connection", return_value=None),
                  patch.object(bot, "PAYMENT_CARD_NUMBER", "8600123412341234"),
                  patch.object(bot, "PAYMENT_CARD_HOLDER", "Malika Abdukarimova")):
            p.start()
            self.addCleanup(p.stop)

    def lang(self, lang):
        p = patch.object(bot, "get_lang", return_value=lang)
        p.start()
        self.addCleanup(p.stop)


class MenuTests(Base):
    def test_prices_and_names_match_spec(self):
        self.assertEqual([(k, p) for k, _, p in bot.PLANS], [("free", 0), ("plus", 2000), ("pro", 5000), ("ultra", 10000)])

    def test_main_menu_has_plans_button(self):
        self.assertIn("plans", [b.callback_data for b in buttons(bot.main_menu_markup(USER))])

    def test_everyone_starts_on_free_marked_active(self):
        with patch.object(db, "get_user_plan", return_value="free"):
            text, markup = bot.build_plans_menu(USER)
        labels = [b.text for b in buttons(markup)]
        self.assertEqual(labels[0], "\U0001F530 Bepul - FAOL ✅")
        self.assertEqual(labels[1:4], ["⏰ Plus - 2,000 so'm", "✨ Pro - 5,000 so'm", "⭐ Ultra - 10,000 so'm"])
        self.assertEqual([b.callback_data for b in buttons(markup)][:4], ["plan:free", "plan:plus", "plan:pro", "plan:ultra"])

    def test_paid_plan_marked_active_instead_of_free(self):
        with patch.object(db, "get_user_plan", return_value="pro"):
            _, markup = bot.build_plans_menu(USER)
        labels = [b.text for b in buttons(markup)]
        self.assertEqual(labels[0], "\U0001F530 Bepul")
        self.assertIn("FAOL", labels[2])

    def test_menu_translated(self):
        for lang, word in (("en", "UZS"), ("ru", "сум")):
            self.lang(lang)
            with patch.object(db, "get_user_plan", return_value="free"):
                _, markup = bot.build_plans_menu(USER)
            self.assertIn(word, buttons(markup)[1].text)
            patch.stopall()
            self.setUp()

    def test_database_error_defaults_to_free(self):
        with patch.object(db, "get_user_plan", side_effect=RuntimeError("x")):
            _, markup = bot.build_plans_menu(USER)
        self.assertIn("FAOL", buttons(markup)[0].text)


class PayScreenTests(Base):
    def test_paid_plan_shows_card_and_holder_with_copyable_number(self):
        with patch.object(db, "get_user_plan", return_value="free"):
            text, markup = bot.build_plan_view(USER, "ultra")
        self.assertIn("<code>8600 1234 1234 1234</code>", text)
        self.assertIn("Malika Abdukarimova", text)
        self.assertIn("10,000", text)
        self.assertEqual(buttons(markup)[0].url, "https://t.me/MyAndro1d")

    def test_screen_in_each_language(self):
        for lang, holder_label in (("en", "Card holder"), ("ru", "Владелец карты"), ("uz", "Karta egasi")):
            with patch.object(bot, "get_lang", return_value=lang), patch.object(db, "get_user_plan", return_value="free"):
                text, _ = bot.build_plan_view(USER, "plus")
            self.assertIn(holder_label, text, lang)
            self.assertIn("Malika Abdukarimova", text)

    def test_free_plan_info_and_no_card(self):
        with patch.object(db, "get_user_plan", return_value="free"):
            text, _ = bot.build_plan_view(USER, "free")
        self.assertNotIn("8600", text)
        self.assertIn(i18n.T["plan_current"]["uz"], text)

    def test_current_paid_plan_does_not_ask_for_payment(self):
        with patch.object(db, "get_user_plan", return_value="plus"):
            text, _ = bot.build_plan_view(USER, "plus")
        self.assertNotIn("8600", text)

    def test_missing_card_is_reported_not_crashing(self):
        with patch.object(bot, "PAYMENT_CARD_NUMBER", ""), patch.object(db, "get_user_plan", return_value="free"):
            text, _ = bot.build_plan_view(USER, "pro")
        self.assertIn(i18n.T["plan_no_card"]["uz"], text)

    def test_html_is_safe(self):
        with patch.object(bot, "PAYMENT_CARD_HOLDER", "A <b> & C"), patch.object(db, "get_user_plan", return_value="free"):
            text, _ = bot.build_plan_view(USER, "pro")
        self.assertIn("A &lt;b&gt; &amp; C", text)

    def test_templates_have_no_html_specials(self):
        for key in ("plan_pay", "plan_free_info", "plan_current", "plan_no_card", "plans_menu"):
            for lang in i18n.LANGS:
                self.assertFalse(re.search(r"[<>&]", i18n.T[key][lang]), f"{key}/{lang}")

    def test_card_formatting(self):
        self.assertEqual(bot.format_card_number("8600123412341234"), "8600 1234 1234 1234")
        self.assertEqual(bot.format_card_number("8600 1234 1234 1234"), "8600 1234 1234 1234")
        self.assertEqual(bot.format_card_number("abc"), "abc")


class CallbackTests(Base):
    def _press(self, data):
        update = MagicMock()
        q = AsyncMock()
        q.data = data
        q.from_user.id = USER
        q.from_user.username = "x"
        q.from_user.full_name = "X"
        update.callback_query = q
        return update, q

    def test_plans_and_plan_buttons(self):
        with patch.object(db, "get_user_plan", return_value="free"):
            u, q = self._press("plans")
            run(bot.on_button(u, MagicMock()))
            self.assertIn("Tarif rejalarimiz", q.edit_message_text.call_args.args[0])
            u, q = self._press("plan:pro")
            run(bot.on_button(u, MagicMock()))
            self.assertEqual(q.edit_message_text.call_args.kwargs["parse_mode"], "HTML")
            self.assertIn("8600 1234 1234 1234", q.edit_message_text.call_args.args[0])

    def test_unknown_plan_ignored(self):
        u, q = self._press("plan:gold")
        run(bot.on_button(u, MagicMock()))
        q.edit_message_text.assert_not_called()


class SetPlanTests(Base):
    def _update(self, uid=ADMIN):
        u = MagicMock()
        u.effective_user.id = uid
        u.message.reply_text = AsyncMock()
        return u

    def _ctx(self, args):
        c = MagicMock()
        c.args = args
        return c

    def test_admin_sets_plan_and_user_notified_in_own_language(self):
        u = self._update()
        with patch.object(bot, "ADMIN_ID", ADMIN), patch.object(bot, "resolve_target_user", AsyncMock(return_value=(77, None))), \
             patch.object(db, "set_user_plan") as setp, patch.object(db, "get_user", return_value={}), \
             patch.object(bot, "get_lang", return_value="ru"), patch.object(bot, "_try_send", AsyncMock(return_value=True)) as send:
            run(bot.cmd_setplan(u, self._ctx(["@ali", "PRO"])))
        setp.assert_called_once_with(77, "pro", None)
        self.assertEqual(send.call_args.args[2], i18n.T["plan_activated"]["ru"].format(name="Pro"))

    def test_non_admin_ignored(self):
        u = self._update(uid=5)
        with patch.object(bot, "ADMIN_ID", ADMIN), patch.object(db, "set_user_plan") as setp:
            run(bot.cmd_setplan(u, self._ctx(["@ali", "pro"])))
        setp.assert_not_called()
        u.message.reply_text.assert_not_called()

    def test_bad_plan_shows_usage(self):
        u = self._update()
        with patch.object(bot, "ADMIN_ID", ADMIN), patch.object(db, "set_user_plan") as setp:
            run(bot.cmd_setplan(u, self._ctx(["@ali", "gold"])))
        setp.assert_not_called()
        self.assertIn("Foydalanish", u.message.reply_text.call_args.args[0])

    def test_registered_and_in_help(self):
        self.assertIn("/setplan", bot.ADMIN_HELP_TEXT)


@unittest.skipUnless(TEST_DB_URL, "TEST_DATABASE_URL yo'q")
class PlanDbTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()
        db.init_db()

    def setUp(self):
        self.uid = random.randint(10**14, 10**15)
        self.addCleanup(self._cleanup)

    def _cleanup(self):
        with db.get_conn() as c, c.cursor() as cur:
            cur.execute("DELETE FROM users WHERE user_id = %s", (self.uid,))

    def test_new_and_unknown_users_are_free(self):
        self.assertEqual(db.get_user_plan(self.uid), "free")
        db.record_user(self.uid, username="a", full_name="A")
        self.assertEqual(db.get_user_plan(self.uid), "free")

    def test_set_and_overwrite_plan_keeps_language(self):
        db.set_user_lang(self.uid, "ru")
        db.set_user_plan(self.uid, "pro")
        self.assertEqual(db.get_user_plan(self.uid), "pro")
        db.set_user_plan(self.uid, "free")
        self.assertEqual(db.get_user_plan(self.uid), "free")
        self.assertEqual(db.get_user_lang(self.uid), "ru")

    def test_plan_survives_record_user(self):
        db.set_user_plan(self.uid, "ultra")
        db.record_user(self.uid, username="b", full_name="B")
        self.assertEqual(db.get_user_plan(self.uid), "ultra")
