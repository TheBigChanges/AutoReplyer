"""Majburiy obuna HAR BIR funksiyaga: bot xabarlari/tugmalari, avtojavob, AI, ism soati, BIO."""
import asyncio
import os
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("BOT_TOKEN", "123:dummy")
os.environ.setdefault("DATABASE_URL", "postgresql://fake/fake")

import bot  # noqa: E402
import db  # noqa: E402
from telegram.error import TelegramError  # noqa: E402
from telegram.ext import ApplicationHandlerStop  # noqa: E402

USER, ADMIN = 777, 1
run = asyncio.run


class Base(unittest.TestCase):
    def setUp(self):
        for target, value in (("REQUIRED_CHANNEL_ID", -100), ("REQUIRED_CHANNEL_LINK", "https://t.me/x"), ("ADMIN_ID", ADMIN)):
            p = patch.object(bot, target, value)
            p.start()
            self.addCleanup(p.stop)
        bot._sub_cache.clear()
        bot._sub_notice_at.clear()
        bot._gate_reply_at.clear()
        self.addCleanup(bot._sub_cache.clear)

    def ctx(self, status="left"):
        c = MagicMock()
        c.bot.get_chat_member = AsyncMock(return_value=MagicMock(status=status))
        c.bot.send_message = AsyncMock()
        return c


def msg_update(text, uid=USER, chat_type="private"):
    u = MagicMock()
    u.callback_query = None
    u.effective_user = MagicMock(id=uid, is_bot=False)
    u.effective_chat = MagicMock(type=chat_type)
    u.message.text = text
    u.message.reply_text = AsyncMock()
    return u


def cb_update(data, uid=USER):
    u = MagicMock()
    u.message = None
    u.effective_user = MagicMock(id=uid, is_bot=False)
    u.effective_chat = MagicMock(type="private")
    q = AsyncMock()
    q.data = data
    u.callback_query = q
    return u, q


class PanelGateTests(Base):
    def test_unsubscribed_text_and_commands_are_stopped(self):
        for text in ("salom", "/help", "/cancel", "/tariflar"):
            u = msg_update(text)
            with self.assertRaises(ApplicationHandlerStop):
                run(bot.subscribe_gate(u, self.ctx()))
            u.message.reply_text.assert_awaited_once()
            bot._gate_reply_at.clear()

    def test_unsubscribed_buttons_are_stopped(self):
        u, q = cb_update("open_panel")
        with self.assertRaises(ApplicationHandlerStop):
            run(bot.subscribe_gate(u, self.ctx()))
        q.answer.assert_awaited()

    def test_start_language_and_check_pass_through(self):
        for text in ("/start", "/start ref_5", "/start@mybot"):
            run(bot.subscribe_gate(msg_update(text), self.ctx()))
        for data in ("check_subscription", "check_subscription:5", "lang:uz", "lang:en:5"):
            u, _ = cb_update(data)
            run(bot.subscribe_gate(u, self.ctx()))

    def test_subscribed_passes(self):
        for status in ("member", "administrator", "creator"):
            bot._sub_cache.clear()
            run(bot.subscribe_gate(msg_update("salom"), self.ctx(status)))

    def test_admin_and_groups_exempt(self):
        c = self.ctx()
        run(bot.subscribe_gate(msg_update("salom", uid=ADMIN), c))
        run(bot.subscribe_gate(msg_update("salom", chat_type="group"), c))
        c.bot.get_chat_member.assert_not_awaited()

    def test_disabled_when_channel_not_configured(self):
        with patch.object(bot, "REQUIRED_CHANNEL_ID", None):
            c = self.ctx()
            run(bot.subscribe_gate(msg_update("salom"), c))
            c.bot.get_chat_member.assert_not_awaited()

    def test_api_error_fails_open(self):
        c = self.ctx()
        c.bot.get_chat_member = AsyncMock(side_effect=TelegramError("no admin"))
        run(bot.subscribe_gate(msg_update("salom"), c))
        self.assertNotIn(USER, bot._sub_cache)

    def test_reply_is_throttled_but_still_stops(self):
        c = self.ctx()
        u1, u2 = msg_update("a"), msg_update("b")
        for u in (u1, u2):
            with self.assertRaises(ApplicationHandlerStop):
                run(bot.subscribe_gate(u, c))
        u1.message.reply_text.assert_awaited_once()
        u2.message.reply_text.assert_not_awaited()

    def test_cache_avoids_repeated_api_calls_and_expires(self):
        c = self.ctx("member")
        for _ in range(3):
            run(bot.subscribe_gate(msg_update("x"), c))
        self.assertEqual(c.bot.get_chat_member.await_count, 1)
        bot._sub_cache[USER] = (time.time() - bot.SUB_CACHE_OK_SECONDS - 1, True)
        run(bot.subscribe_gate(msg_update("x"), c))
        self.assertEqual(c.bot.get_chat_member.await_count, 2)

    def test_non_member_rechecked_quickly_after_subscribing(self):
        c = self.ctx("left")
        with self.assertRaises(ApplicationHandlerStop):
            run(bot.subscribe_gate(msg_update("x"), c))
        c.bot.get_chat_member = AsyncMock(return_value=MagicMock(status="member"))
        bot._sub_cache[USER] = (time.time() - bot.SUB_CACHE_NO_SECONDS - 1, False)
        run(bot.subscribe_gate(msg_update("x"), c))


class BusinessTests(Base):
    def _bm_update(self):
        u = MagicMock()
        u.channel_post = None
        u.business_connection = None
        bm = u.business_message
        bm.business_connection_id = "bc"
        bm.from_user = MagicMock(id=555)
        bm.chat.id = 555
        bm.message_id = 1
        bm.text = "salom"
        return u

    def _go(self, c):
        conn = {"owner_user_id": USER, "is_enabled": True, "can_reply": True}
        with patch.object(db, "get_connection_by_business_id", return_value=conn), \
             patch.object(db, "get_settings") as gs:
            run(bot.on_raw_update(self._bm_update(), c))
        return gs

    def test_unsubscribed_owner_gets_no_autoreply_and_one_notice(self):
        c = self.ctx("left")
        gs = self._go(c)
        gs.assert_not_called()  # avtojavob logikasigacha yetmadi
        self.assertEqual(c.bot.send_message.await_count, 1)
        self.assertEqual(c.bot.send_message.call_args.kwargs["chat_id"], USER)
        self._go(c)
        self.assertEqual(c.bot.send_message.await_count, 1)  # xabarnoma qaytarilmaydi

    def test_subscribed_owner_continues(self):
        c = self.ctx("member")
        gs = self._go(c)
        gs.assert_called()


class ClockAndBioTests(Base):
    def test_sub_ok_sync_uses_cache_only(self):
        self.assertTrue(bot.sub_ok_sync(USER))  # noma'lum — ruxsat
        bot._sub_cache[USER] = (time.time(), False)
        self.assertFalse(bot.sub_ok_sync(USER))
        self.assertTrue(bot.sub_ok_sync(ADMIN))

    def test_tick_skips_unsubscribed(self):
        bot._sub_cache[USER] = (time.time(), False)
        targets = [
            {"owner_user_id": USER, "business_connection_id": "a", "name_clock_tz": None, "name_clock_first": "A",
             "name_clock_last": None, "name_clock_applied": None, "name_clock_style": None, "plan": "ultra"},
        ]
        with patch.object(db, "get_name_clock_targets", return_value=targets), \
             patch.object(bot, "_apply_clock", new=AsyncMock()) as apply_:
            run(bot.name_clock_tick(MagicMock(), time.time()))
        apply_.assert_not_awaited()

    def test_bio_skips_unsubscribed(self):
        bot._sub_cache[USER] = (time.time(), False)
        row = {"owner_user_id": USER, "plan": "ultra", "bio_countdown_target": "newyear", "birthday_month": None,
               "birthday_day": None, "business_connection_id": "bc", "bio_updated_on": None, "lang": "uz"}
        b = MagicMock()
        b.set_business_account_bio = AsyncMock()
        with patch.object(db, "get_all_bio_targets", return_value=[row]):
            run(bot.refresh_bios(b, only_stale=False))
        b.set_business_account_bio.assert_not_awaited()


class RefreshJobTests(Base):
    def test_lost_subscription_restores_name_and_notifies_once(self):
        bot._sub_cache[USER] = (time.time() - bot.SUB_CACHE_OK_SECONDS - 1, True)
        c = self.ctx("left")
        with patch.object(db, "get_name_clock_targets", return_value=[{"owner_user_id": USER}]), \
             patch.object(db, "get_all_bio_targets", return_value=[]), \
             patch.object(bot, "restore_base_name", new=AsyncMock(return_value=True)) as restore, \
             patch.object(bot.asyncio, "sleep", new=AsyncMock()):
            run(bot.subscription_refresh_job(c))
            restore.assert_awaited_once()
            self.assertEqual(c.bot.send_message.await_count, 1)
            # kesh yangi — qayta tekshirilmaydi
            run(bot.subscription_refresh_job(c))
            restore.assert_awaited_once()

    def test_still_subscribed_does_nothing(self):
        c = self.ctx("member")
        with patch.object(db, "get_name_clock_targets", return_value=[{"owner_user_id": USER}]), \
             patch.object(db, "get_all_bio_targets", return_value=[]), \
             patch.object(bot, "restore_base_name", new=AsyncMock()) as restore, \
             patch.object(bot.asyncio, "sleep", new=AsyncMock()):
            run(bot.subscription_refresh_job(c))
        restore.assert_not_awaited()
        c.bot.send_message.assert_not_awaited()


class WiringTests(unittest.TestCase):
    def test_gate_registered_before_handlers_and_after_block_gate(self):
        app = bot.build_app()
        by_group = {g: [h.callback for h in hs] for g, hs in app.handlers.items()}
        self.assertIn(bot.block_gate, by_group[-3])
        self.assertIn(bot.subscribe_gate, by_group[-2])
        self.assertLess(-3, -2)


class DispatcherTests(Base):
    """Haqiqiy PTB dispatcher: obuna bo'lmagan odamning matni on_text'ga yetmaydi, /start yetadi."""

    def _run(self, text, status):
        from telegram import Update, User
        from telegram.ext import ExtBot
        seen = []
        patches = [
            patch.object(bot, "on_text", AsyncMock(side_effect=lambda *a: seen.append("on_text"))),
            patch.object(bot, "cmd_start", AsyncMock(side_effect=lambda *a: seen.append("cmd_start"))),
        ]
        for pt in patches:
            pt.start()
            self.addCleanup(pt.stop)
        app = bot.build_app()
        app.bot._bot_user = User(id=1, first_name="Bot", is_bot=True, username="testbot")
        entities = [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}] if text.startswith("/") else []
        upd = Update.de_json({"update_id": 1, "message": {
            "message_id": 1, "date": 1_700_000_000, "text": text, "entities": entities,
            "chat": {"id": USER, "type": "private", "first_name": "X"},
            "from": {"id": USER, "is_bot": False, "first_name": "X"}}}, app.bot)
        sent = AsyncMock()

        async def go():
            with patch.object(ExtBot, "initialize", AsyncMock()):
                await app.initialize()
            with patch.object(ExtBot, "get_chat_member", AsyncMock(return_value=MagicMock(status=status))), \
                 patch.object(ExtBot, "send_message", sent), \
                 patch("telegram.Message.reply_text", AsyncMock()) as reply, \
                 patch.object(db, "get_block", return_value=None), \
                 patch.object(bot, "track_user"):
                await app.process_update(upd)
                return reply

        reply = run(go())
        return seen, reply

    def test_unsubscribed(self):
        seen, reply = self._run("salom", "left")
        self.assertEqual(seen, [])
        reply.assert_awaited()
        seen, _ = self._run("/start", "left")
        self.assertEqual(seen, ["cmd_start"])

    def test_subscribed(self):
        seen, _ = self._run("salom", "member")
        self.assertEqual(seen, ["on_text"])


if __name__ == "__main__":
    unittest.main()
